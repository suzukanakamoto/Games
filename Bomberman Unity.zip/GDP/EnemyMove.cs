﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMove : MonoBehaviour {

	Rigidbody2D rb;
	public float moveForce = 100f;
	public float maxSpeed = 2f; // 2unit(meter) perdetik
	bool directionHoriz; 
	public float intervalMoveDirection = 2f; // bergerak kembali setelah durasi ini

	void Start () {
		rb = GetComponent<Rigidbody2D> ();
		RandomDirection ();
		InvokeRepeating ("RandomDirection", intervalMoveDirection, intervalMoveDirection);
	}
	
	void RandomDirection() {
		if ((int)Random.Range (0, 1) == 0) { // horizontal move
			directionHoriz = true;
		} else {
			directionHoriz = false; // vertical
		}
	}

	void FixedUpdate() { 
		if (directionHoriz && Mathf.Abs (rb.velocity.x) < maxSpeed) {
			float x = Random.Range (-1, 1); // kiri/kanan
			rb.AddForce (new Vector2 (x, 0) * moveForce);
		} else if (Mathf.Abs (rb.velocity.y) < maxSpeed) {
			float y = Random.Range (-1, 1); // atas/bawah
			rb.AddForce (new Vector2 (0, y) * moveForce);
		}
	}
}
